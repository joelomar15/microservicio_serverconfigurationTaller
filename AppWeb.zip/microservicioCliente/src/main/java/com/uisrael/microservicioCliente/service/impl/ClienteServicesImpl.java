package com.uisrael.microservicioCliente.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uisrael.microservicioCliente.model.Cliente;
import com.uisrael.microservicioCliente.repository.IClienteRepository;
import com.uisrael.microservicioCliente.service.IClienteServices;
@Service
public class ClienteServicesImpl implements IClienteServices{
	@Autowired
	private IClienteRepository repo;
	@Override
	public void insertarCliente(Cliente nuevo) {
		// TODO Auto-generated method stub
		repo.save(nuevo);
	}

	@Override
	public List<Cliente> listarCliente() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
