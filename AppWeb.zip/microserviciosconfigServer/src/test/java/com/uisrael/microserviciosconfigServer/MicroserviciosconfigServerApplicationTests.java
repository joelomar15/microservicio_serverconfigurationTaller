package com.uisrael.microserviciosconfigServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviciosconfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
