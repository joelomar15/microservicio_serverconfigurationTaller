package com.uisrael.AppWeb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.uisrael.AppWeb.services.IClienteService;

import com.uisrael.AppWeb.services.model.DTO.ClienteDTO;

@Controller
public class ClienteController {

	@Autowired
	private IClienteService servicio;
	
	@GetMapping("/app/listaCliente")
	public String listarCliente(Model model) {
		List<ClienteDTO> resultado = servicio.listaCliente();
		model.addAttribute("lista",resultado);
		return "Cliente/listaCliente";
	}
}
