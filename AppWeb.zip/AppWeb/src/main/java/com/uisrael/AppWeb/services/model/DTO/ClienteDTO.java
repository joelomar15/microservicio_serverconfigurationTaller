package com.uisrael.AppWeb.services.model.DTO;

import java.util.Date;

import lombok.Data;

@Data
public class ClienteDTO {
	private String idCliente;
	private String nombre;
	private String apellido;
	private String direccion;
	private String ci;
	private Date fechaNacimiento;
	private boolean estado;
	private TipoClienteDTO tipoCliente;
}
