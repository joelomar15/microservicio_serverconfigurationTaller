package com.uisrael.AppWeb.services;

import java.util.List;

import com.uisrael.AppWeb.services.model.DTO.ClienteDTO;



public interface IClienteService {
	public List<ClienteDTO> listaCliente();
}
