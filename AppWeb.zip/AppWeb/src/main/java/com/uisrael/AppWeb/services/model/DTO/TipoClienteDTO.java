package com.uisrael.AppWeb.services.model.DTO;

import java.util.List;

import lombok.Data;

@Data
public class TipoClienteDTO {
	private String idTipoCliente;
	private String descripcion;
	private String estado;
	private List<ClienteDTO> cliente;
}
