package com.uisrael.AppWeb.services;

import java.util.List;

import com.uisrael.AppWeb.services.model.DTO.TipoClienteDTO;


public interface ITipoClienteService {
	public List<TipoClienteDTO> listaTipoCliente();
}
