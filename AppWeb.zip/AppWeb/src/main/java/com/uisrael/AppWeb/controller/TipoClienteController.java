package com.uisrael.AppWeb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.uisrael.AppWeb.services.ITipoClienteService;
import com.uisrael.AppWeb.services.model.DTO.TipoClienteDTO;

@Controller
public class TipoClienteController {

	@Autowired
	private ITipoClienteService servicio;
	
	@GetMapping("/app/listaTipoCliente")
	public String listarTipoCliente(Model model) {
		List<TipoClienteDTO> resultado = servicio.listaTipoCliente();
		model.addAttribute("lista",resultado);
		return "TipoCliente/listaTipoCliente";
	}
}
