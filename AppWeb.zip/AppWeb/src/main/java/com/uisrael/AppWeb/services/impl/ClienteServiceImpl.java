package com.uisrael.AppWeb.services.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.uisrael.AppWeb.services.IClienteService;
import com.uisrael.AppWeb.services.model.DTO.ClienteDTO;
import com.uisrael.AppWeb.util.ConvertJson;

@Service
public class ClienteServiceImpl implements IClienteService{


	@Autowired
	private RestTemplate gestionRest;


	@Override
	public List<ClienteDTO> listaCliente() {
		// TODO Auto-generated method stub
		List<String> Cliente = Arrays
				.asList(gestionRest.getForObject("http://localhost:50242/api/categoria/listarCategoria", String.class));
		ConvertJson<ClienteDTO> convertir = new ConvertJson<>(ClienteDTO.class);
		List<ClienteDTO> ClientDTO = convertir.convertJsonDTO(Cliente);
		return ClientDTO;
	}

}
