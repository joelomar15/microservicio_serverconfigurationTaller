package com.uisrael.AppWeb.util;
import java.util.List;
import com.google.gson.Gson;
import lombok.Data;
import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;
@Data
public class ConvertJson<T> {
	private final Class<T> objectType;
	private final Gson gson; 
	
	public ConvertJson(Class<T> objectType)	{
		this.gson = new Gson();
		this.objectType = objectType;
	}
	
	public List<T> convertJsonDTO(List<String> jsonList) {
		String jsonString = String.join("", jsonList);
	    //String jsonString = jsonList.stream().collect(Collectors.joining());
	    Type listType = TypeToken.getParameterized(List.class, objectType).getType();
	    return gson.fromJson(jsonString, listType);
    }
	
	public T convertJsonToSingleObject(String jsonString) {
        try {
            return gson.fromJson(jsonString, objectType);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
