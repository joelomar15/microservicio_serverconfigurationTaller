package com.uisrael.AppWeb.services.impl;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.uisrael.AppWeb.services.ITipoClienteService;
import com.uisrael.AppWeb.services.model.DTO.TipoClienteDTO;
import com.uisrael.AppWeb.util.ConvertJson;
@Service
public class TipoClienteServiceImpl implements ITipoClienteService{

	
	@Autowired
	private RestTemplate gestionRest;

	@Override
	public List<TipoClienteDTO> listaTipoCliente() {
		// TODO Auto-generated method stub
		List<String> tipoClient = Arrays
				.asList(gestionRest.getForObject("http://localhost:50242/api/categoria/listarCategoria", String.class));
		ConvertJson<TipoClienteDTO> convertir = new ConvertJson<>(TipoClienteDTO.class);
		List<TipoClienteDTO> tipoClientDTO = convertir.convertJsonDTO(tipoClient);
		return tipoClientDTO;
	}

}
