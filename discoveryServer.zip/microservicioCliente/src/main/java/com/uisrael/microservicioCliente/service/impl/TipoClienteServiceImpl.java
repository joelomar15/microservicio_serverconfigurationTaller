package com.uisrael.microservicioCliente.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uisrael.microservicioCliente.model.TipoCliente;
import com.uisrael.microservicioCliente.repository.ITipoClienteRepository;
import com.uisrael.microservicioCliente.service.ITipoClienteService;

@Service
public class TipoClienteServiceImpl implements ITipoClienteService{

	@Autowired
	private ITipoClienteRepository repo;
	@Override
	public void insertarTipoCliente(TipoCliente nuevo) {
		// TODO Auto-generated method stub
		repo.save(nuevo);
	}

	@Override
	public List<TipoCliente> listarTipoCliente() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
