package com.uisrael.microservicioCliente.service;

import java.util.List;

import com.uisrael.microservicioCliente.model.Cliente;

public interface IClienteServices {
	public void insertarCliente(Cliente nuevo);
	public List<Cliente>listarCliente();
}
