package com.uisrael.microservicioCliente.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.uisrael.microservicioCliente.model.TipoCliente;
@Repository
public interface ITipoClienteRepository extends MongoRepository<TipoCliente, String> {

}
