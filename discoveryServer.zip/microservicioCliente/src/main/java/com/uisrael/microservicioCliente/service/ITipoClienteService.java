package com.uisrael.microservicioCliente.service;

import java.util.List;

import com.uisrael.microservicioCliente.model.TipoCliente;

public interface ITipoClienteService {
	public void insertarTipoCliente(TipoCliente nuevo);
	public List<TipoCliente>listarTipoCliente();
}
